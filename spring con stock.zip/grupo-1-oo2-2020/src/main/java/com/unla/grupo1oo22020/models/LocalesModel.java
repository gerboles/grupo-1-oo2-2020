package com.unla.grupo1oo22020.models;

public class LocalesModel {
	private LocalModel local1;
	private LocalModel local2;
	
	public LocalesModel(LocalModel local1, LocalModel local2) {
		super();
		this.local1 = local1;
		this.local2 = local2;
	}
	
	public LocalModel getLocal1() {
		return local1;
	}

	public void setLocal1(LocalModel local1) {
		this.local1 = local1;
	}

	public LocalModel getLocal2() {
		return local2;
	}

	public void setLocal2(LocalModel local2) {
		this.local2 = local2;
	}
	

}
